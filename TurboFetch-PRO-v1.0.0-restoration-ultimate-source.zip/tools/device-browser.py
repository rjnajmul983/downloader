import subprocess,time,re,pathlib,xml.etree.ElementTree as ET
out=pathlib.Path('build/logs/device')
def adb(*args):return subprocess.check_output(['adb',*args])
def dump(name):
 adb('shell','uiautomator','dump','/sdcard/turbo-browser.xml');raw=adb('shell','cat','/sdcard/turbo-browser.xml');(out/(name+'.xml')).write_bytes(raw);return ET.fromstring(raw)
def click(node):
 a,b,c,d=map(int,re.findall(r'\d+',node.attrib['bounds']));adb('shell','input','tap',str((a+c)//2),str((b+d)//2))
def find(root,pred):return next((n for n in root.iter('node') if pred(n.attrib)),None)
def val(a):return (a.get('text','')+' '+a.get('content-desc','')).lower()
def must(n,what):
 if n is None:raise AssertionError('Missing UI control: '+what)
 return n
r=dump('browser-before');b=find(r,lambda a:'browser' in val(a) and a.get('clickable')=='true' and 'open url in' not in val(a))
if b is None:
 b=find(r,lambda a:'open url in browser' in val(a))
click(must(b,'Browser'));time.sleep(3)
r=dump('browser-open');address=find(r,lambda a:a.get('class')=='android.widget.EditText')
click(must(address,'Browser address'));adb('shell','input','keyevent','KEYCODE_MOVE_END');
adb('shell','input','keycombination','113','29') # CTRL+A, supported on current emulator
adb('shell','input','text','http://127.0.0.1:18765/index.html');adb('shell','input','keyevent','66');time.sleep(5)
r=dump('browser-loaded');click(must(find(r,lambda a:'find files' in val(a)),'Find Files'));time.sleep(5)
r=dump('browser-scanned');visible=' '.join(val(n.attrib) for n in r.iter('node'))
if not any('sample.'+ext in visible for ext in ('zip','pdf','mp4')):raise AssertionError('Scanner candidate not visible; inspect XML and screenshot')
(out/'browser-scanned.png').write_bytes(adb('exec-out','screencap','-p'));print('PASS original Browser Find Files exposed controlled local candidate (not a full protocol regression)')
