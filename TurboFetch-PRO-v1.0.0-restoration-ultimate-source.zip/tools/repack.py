#!/usr/bin/env python3
import zipfile,struct,sys,re,hashlib,pathlib
original, rebuilt, bridge, output = sys.argv[1:]
def manifest(data):
    b=bytearray(data);u=lambda p:struct.unpack_from('<I',b,p)[0];h=lambda p:struct.unpack_from('<H',b,p)[0]
    p=8;ss=[];patched=set()
    while p<len(b):
        t=h(p);hs=h(p+2);size=u(p+4)
        if size<8 or p+size>len(b):raise ValueError('Invalid AXML')
        if t==1:
            count=u(p+8);flags=u(p+16);start=u(p+20)
            if flags&256:raise ValueError('Expected original UTF16 pool')
            for i in range(count):
                q=p+start+u(p+hs+4*i);n=h(q);q+=2
                if n&0x8000:raise ValueError('Unexpected long string')
                ss.append((bytes(b[q:q+2*n]).decode('utf-16le'),q,n))
        elif t==0x102:
            tag=ss[u(p+20)][0];at=p+16+h(p+24);num=h(p+28);asz=h(p+26)
            for i in range(num):
                q=at+asz*i;name=ss[u(q+4)][0];dt=b[q+15];v=u(q+16)
                if tag=='manifest' and name=='versionCode':
                    if dt!=0x10 or v!=4:raise ValueError('Unexpected versionCode')
                    struct.pack_into('<I',b,q+16,10005);patched.add(name)
                if tag=='manifest' and name=='versionName':
                    old,pos,n=ss[v]
                    if dt!=3 or old!='0.4.0' or n!=5:raise ValueError('Unexpected versionName')
                    b[pos:pos+2*n]='1.0.0'.encode('utf-16le');patched.add(name)
                if tag=='application' and name=='debuggable':
                    if dt!=0x12:raise ValueError('Unexpected debuggable')
                    struct.pack_into('<I',b,q+16,0);patched.add(name)
    
        p+=size
    if patched!={'versionCode','versionName','debuggable'}:raise ValueError(f'Manifest patch missing {patched}')
    return bytes(b)
def sig(n):
    return n.upper()=='META-INF/MANIFEST.MF' or (n.upper().startswith('META-INF/') and n.upper().endswith(('.SF','.RSA','.DSA','.EC')))
changed={'classes3.dex','classes6.dex','classes8.dex'}
with zipfile.ZipFile(original) as old,zipfile.ZipFile(rebuilt) as new,zipfile.ZipFile(output,'w') as out:
    if 'classes9.dex' in old.namelist():raise ValueError('DEX collision')
    for info in old.infolist():
        n=info.filename
        if sig(n):continue
        data=old.read(n)
        if n in changed:
            data=new.read(n)
            if not data.startswith(b'dex\n'):raise ValueError('Invalid rebuilt DEX')
        if n=='AndroidManifest.xml':data=manifest(data)
        out.writestr(info,data)
    out.write(bridge,'classes9.dex',compress_type=zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(original) as old,zipfile.ZipFile(output) as out:
    kept=[n for n in old.namelist() if n not in changed|{'AndroidManifest.xml'} and not sig(n)]
    for n in kept:
        if old.read(n)!=out.read(n):raise ValueError('Original entry changed: '+n)
    print(f'Preserved {len(kept)} original entries byte-for-byte; modified only 3 DEX, manifest, signing; added classes9.dex')
    libs=[n for n in kept if n.startswith('lib/')];print('Preserved native libs:',libs)
