#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${APKTOOL_JAR:?APKTOOL_JAR required}"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
: "${SDK:?Android SDK required}"
BT="$SDK/build-tools/35.0.0"
ORIGINAL=original/TurboFetch-Download-Manager-v0.4.0.apk
sha256sum -c original/SHA256SUMS
mkdir -p build/output build/logs
java -jar "$APKTOOL_JAR" d -f -r "$ORIGINAL" -o build/decoded 2>&1 | tee build/logs/apktool-decode.txt
# Save pristine disassembly (recovery artifact, no binary resources re-encoding needed).
mkdir -p build/recovered-smali
for d in build/decoded/smali*; do cp -a "$d" build/recovered-smali/; done
cp build/decoded/apktool.yml build/recovered-smali/
python3 tools/patch-smali.py build/decoded | tee build/logs/patch.txt
java -jar "$APKTOOL_JAR" b build/decoded -o build/rebuilt.apk 2>&1 | tee build/logs/apktool-build.txt
mkdir -p build/java build/d8
javac --release 17 -d build/java $(find core/src/main/java bridge/src bridge/stubs -name '*.java')
javac --release 17 -cp "build/java:$SDK/platforms/android-35/android.jar" -d build/java $(find bridge/android -name '*.java')
jar --create --file build/core.jar -C build/java com/turbofetch/core
jar --create --file build/stubs.jar -C build/java com/turbofetch/app
"$BT/d8" --release --min-api 29 --lib "$SDK/platforms/android-35/android.jar" --classpath build/stubs.jar --output build/d8 build/core.jar 2>&1 | tee build/logs/d8.txt
test -f build/d8/classes.dex
test ! -f build/d8/classes2.dex
python3 tools/repack.py "$ORIGINAL" build/rebuilt.apk build/d8/classes.dex build/restoration-unsigned.apk | tee build/logs/preservation.txt
python3 tools/verify-preservation.py "$ORIGINAL" build/restoration-unsigned.apk | tee -a build/logs/preservation.txt
"$BT/zipalign" -P 16 -f 4 build/restoration-unsigned.apk build/restoration-aligned.apk
# Owner-controlled signing recommended; otherwise CI creates a test key (not reusable).
if [[ -n "${KEYSTORE_B64:-}" ]]; then
  : "${STORE_PASSWORD:?TURBO_STORE_PASSWORD missing}" "${KEY_ALIAS:?TURBO_KEY_ALIAS missing}" "${KEY_PASSWORD:?TURBO_KEY_PASSWORD missing}"
  umask 077; printf '%s' "$KEYSTORE_B64" | base64 --decode > build/owner.jks
  KEYFILE=build/owner.jks
else
  KEYFILE=build/test-signing.jks; STORE_PASSWORD=android; KEY_ALIAS=turbotest; KEY_PASSWORD=android
  keytool -genkeypair -keystore "$KEYFILE" -storepass "$STORE_PASSWORD" -keypass "$KEY_PASSWORD" -alias "$KEY_ALIAS" -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=TurboFetch CI Test'
fi
export STORE_PASSWORD KEY_PASSWORD
APK=build/output/TurboFetch-PRO-v1.0.0-restoration-ultimate-preview.apk
"$BT/apksigner" sign --ks "$KEYFILE" --ks-key-alias "$KEY_ALIAS" --ks-pass env:STORE_PASSWORD --key-pass env:KEY_PASSWORD --out "$APK" build/restoration-aligned.apk
"$BT/apksigner" verify --verbose --print-certs "$APK" | tee build/logs/signature.txt
"$BT/zipalign" -c -P 16 4 "$APK"
"$BT/aapt" dump badging "$APK" > build/logs/badging.txt
python3 tools/verify-preservation.py "$ORIGINAL" "$APK" | tee -a build/logs/preservation.txt
(cd build/output && sha256sum *.apk > SHA256SUMS)
ls -lh "$APK"
rm -f build/owner.jks build/test-signing.jks
