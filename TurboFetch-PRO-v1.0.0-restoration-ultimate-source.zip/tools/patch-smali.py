#!/usr/bin/env python3
"""Patch six original classes; fail closed on unexpected signatures."""
import re, pathlib, sys
root=pathlib.Path(sys.argv[1])
J='Lcom/turbofetch/app/engine/DownloadJob;'; E='Lcom/turbofetch/app/engine/TurboEngine;'; F='Ljava/io/File;'; L='Lcom/turbofetch/app/engine/TurboEngine$Listener;'; S='Lcom/turbofetch/app/engine/TurboEngine$SpaceCheck;'; B='Lcom/turbofetch/core/LegacyBridge;'; C='Landroid/content/Context;'; T='Lcom/turbofetch/app/TransferProcessor;'
def locate(name):
    files=list(root.glob('smali*/'+name+'.smali'))
    if len(files)!=1: raise ValueError(f'Expected exactly one {name}: {files}')
    return files[0]
def edit(name,fn):
    p=locate(name); s=p.read_text(); p.write_text(fn(s));print('Patched',p.relative_to(root))
def block(s,sig,fn):
    pat=r'(?m)^\.method [^\n]*\b'+re.escape(sig)+r'\s*\n.*?^\.end method\s*$'
    matches=list(re.finditer(pat,s,re.M|re.S))
    if len(matches)!=1: raise ValueError(f'Method count for {sig}: {len(matches)}')
    m=matches[0];return s[:m.start()]+fn(m.group())+s[m.end():]
def add_before_clears(s,call,expected):
    pat=r'(?m)^([ \t]*invoke-interface(?:/range)?\s+\{[^\n]*\}, Ljava/util/List;->clear\(\)V)\s*$'
    s,n=re.subn(pat,lambda m:'    '+call+'\n\n'+m.group(1)+'\n',s)
    if n!=expected:raise ValueError(f'Unexpected clear count {n}, expected {expected}')
    return s
sig='download('+J+F+L+S+')'+F

def engine(s):
    def old(m):
        m=m.replace(sig,'hyperLegacyDownload'+sig[len('download'):],1)
        return add_before_clears(m,f'invoke-static/range {{p1 .. p2}}, {B}->protectLegacy({J}{F})V',3)
    s=block(s,sig,old)
    s=block(s,'prepareParts('+J+'I)V',lambda m:add_before_clears(m,f'invoke-static/range {{p1 .. p1}}, {B}->protectParts({J})V',1))
    return s+f'''
.method public {sig}
    .locals 1
    iget-object v0, p0, {E}->stopped:Ljava/util/concurrent/atomic/AtomicBoolean;
    invoke-static {{p1, p2, p3, p4, v0}}, {B}->download({J}{F}{L}{S}Ljava/util/concurrent/atomic/AtomicBoolean;){F}
    move-result-object v0
    if-nez v0, :hyper_done
    invoke-virtual/range {{p0 .. p4}}, {E}->hyperLegacyDownload({J}{F}{L}{S}){F}
    move-result-object v0
    :hyper_done
    return-object v0
.end method
'''
def history(s):
    sig='lambda$clearFinishedHistory$0('+J+')Z'
    return block(s,sig,lambda m:m.splitlines()[0]+f'''
    .locals 1
    invoke-static {{p0}}, {B}->mayClear({J})Z
    move-result v0
    return v0
.end method\n''')
def options(s):
    def default(m,key,val):
        pat=r'(?m)(const-string(?:/jumbo)?\s+v\d+, "'+key+r'"\s*\n(?:\s*\.[^\n]*\n)*\s*)const/(?:4|16)\s+(v\d+),\s+0x[0-9a-f]+'
        m,n=re.subn(pat,lambda a:a[1]+'const/16 '+a[2]+', '+val,m)
        if n!=1:raise ValueError(f'Unexpected default for {key}: {n}')
        return m
    s=block(s,'connections('+C+')I',lambda m:default(m,'connections','0x20'))
    return block(s,'parallel('+C+')I',lambda m:default(m,'parallel','0x1'))
def processor(s):
    args=C+J+F+'Lcom/turbofetch/app/TransferProcessor$Listener;Lcom/turbofetch/app/TransferProcessor$Controller;'
    sig='run('+args+')V'
    s=block(s,sig,lambda m:m.replace(sig,'hyperLegacyRun('+args+')V',1))
    return s+f'''
.method public static {sig}
    .locals 1
    invoke-static/range {{p0 .. p0}}, Lcom/turbofetch/core/RuntimeSignals;->enter(Ljava/lang/Object;)V
    :try_start_hyper
    invoke-static/range {{p0 .. p4}}, {T}->hyperLegacyRun({args})V
    invoke-static {{p2, p1}}, {B}->cleanup({F}{J})V
    :try_end_hyper
    invoke-static {{}}, Lcom/turbofetch/core/RuntimeSignals;->exit()V
    return-void
    .catchall {{:try_start_hyper .. :try_end_hyper}} :catch_hyper
    :catch_hyper
    move-exception v0
    invoke-static {{}}, Lcom/turbofetch/core/RuntimeSignals;->exit()V
    throw v0
.end method
'''
edit('com/turbofetch/app/engine/TurboEngine',engine)
edit('com/turbofetch/app/JobStore',history)
edit('com/turbofetch/app/TransferOptions',options)
edit('com/turbofetch/app/TransferProcessor',processor)

def settings(s):
    def attach(m):
        m,n=re.subn(r'(?m)^([ \t]*)return-void\s*$',lambda a:a[1]+'invoke-static/range {p0 .. p0}, Lcom/turbofetch/core/DiagnosticsUi;->attach(Landroid/app/Activity;)V\n'+a[1]+'return-void',m)
        if n!=1:raise ValueError(f'Unexpected Settings.onCreate exits: {n}')
        return m
    return block(s,'onCreate(Landroid/os/Bundle;)V',attach)
edit('com/turbofetch/app/SettingsActivity',settings)

# Original FTP engine supports REST but deletes partial files on several restart branches.
# Replace only its three audited File.delete calls; preserve nonempty data on rejection.
def ftp(s):
    sig='download('+J+F+'Lcom/turbofetch/app/ftp/FtpEngine$Listener;'+S+')'+F
    def guard(m):
        pattern=r'invoke-virtual(?P<range>/range)?\s+(?P<regs>\{[^}]+\}), Ljava/io/File;->delete\(\)Z'
        m,n=re.subn(pattern,lambda a:'invoke-static'+(a['range'] or '')+' '+a['regs']+', '+B+'->preserveFtpPartial('+F+')Z',m)
        if n!=3:raise ValueError(f'Unexpected FTP restart deletes: {n}')
        return m
    return block(s,sig,guard)
edit('com/turbofetch/app/ftp/FtpEngine',ftp)
