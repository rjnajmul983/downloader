import pathlib, tempfile, subprocess, sys
p=pathlib.Path(__file__).resolve().parent
J='Lcom/turbofetch/app/engine/DownloadJob;';F='Ljava/io/File;'; L='Lcom/turbofetch/app/engine/TurboEngine$Listener;';S='Lcom/turbofetch/app/engine/TurboEngine$SpaceCheck;';C='Landroid/content/Context;'
clear='    invoke-interface {v0}, Ljava/util/List;->clear()V\n'
def m(header,body):return '.method '+header+'\n    .locals 2\n'+body+'\n.end method\n\n'
with tempfile.TemporaryDirectory() as tmp:
 root=pathlib.Path(tmp);base=root/'smali_classes8/com/turbofetch/app';eng=base/'engine';eng.mkdir(parents=True)
 (eng/'TurboEngine.smali').write_text(m('public download('+J+F+L+S+')'+F,clear*3)+m('private prepareParts('+J+'I)V',clear))
 (base/'JobStore.smali').write_text(m('static synthetic lambda$clearFinishedHistory$0('+J+')Z','    return v0'))
 (base/'TransferOptions.smali').write_text(m('public static connections('+C+')I','    const-string v1, "connections"\n\n    const/16 v2, 0x8')+m('public static parallel('+C+')I','    const-string v1, "parallel"\n\n    .line 12\n    const/4 v2, 0x2'))
 (base/'TransferProcessor.smali').write_text(m('public static run('+C+J+F+'Lcom/turbofetch/app/TransferProcessor$Listener;Lcom/turbofetch/app/TransferProcessor$Controller;)V','    return-void'))
 (base/'SettingsActivity.smali').write_text(m('public onCreate(Landroid/os/Bundle;)V','    return-void'))
 ftp=root/'smali_classes6/com/turbofetch/app/ftp';ftp.mkdir(parents=True)
 (ftp/'FtpEngine.smali').write_text(m('public download('+J+F+'Lcom/turbofetch/app/ftp/FtpEngine$Listener;'+S+')'+F,'    invoke-virtual {v0}, Ljava/io/File;->delete()Z\n    invoke-virtual/range {v20 .. v20}, Ljava/io/File;->delete()Z\n    invoke-virtual {v1}, Ljava/io/File;->delete()Z'))
 subprocess.run([sys.executable,str(p/'patch-smali.py'),str(root)],check=True)
 assert (eng/'TurboEngine.smali').read_text().count('->protectLegacy(')==3
 assert '->download(' in (eng/'TurboEngine.smali').read_text()
 assert 'const/16 v2, 0x20' in (base/'TransferOptions.smali').read_text()
 assert 'const/16 v2, 0x1' in (base/'TransferOptions.smali').read_text()
 assert 'DiagnosticsUi;->attach' in (base/'SettingsActivity.smali').read_text()
 assert 'RuntimeSignals;->exit' in (base/'TransferProcessor.smali').read_text()
 assert (ftp/'FtpEngine.smali').read_text().count('->preserveFtpPartial(')==3
 print('PASS patch text fixture (not actual smali assembly)')
