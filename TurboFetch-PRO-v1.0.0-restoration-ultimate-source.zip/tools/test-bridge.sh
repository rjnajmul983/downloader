#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=$(mktemp -d);trap 'rm -rf "$TMP"' EXIT
javac --release 17 --add-modules jdk.httpserver -d "$TMP" $(find core/src/main/java bridge/src bridge/stubs -name '*.java') bridge/tests/BridgeIntegration.java bridge/tests/TransportBridgeTest.java
java --add-modules jdk.httpserver -cp "$TMP" BridgeIntegration

java -cp "$TMP" TransportBridgeTest
