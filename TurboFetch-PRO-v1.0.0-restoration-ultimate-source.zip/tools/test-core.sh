#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
javac --release 17 --add-modules jdk.httpserver -d "$TMP" $(find core/src/main/java -name '*.java') tests/EngineIntegration.java tests/SmartAutoIntegration.java tests/HyperSpeedIntegration.java tests/PerformancePolicyTest.java tests/TransportIntegration.java
java --add-modules jdk.httpserver -cp "$TMP" EngineIntegration

java --add-modules jdk.httpserver -cp "$TMP" SmartAutoIntegration

java --add-modules jdk.httpserver -cp "$TMP" HyperSpeedIntegration

java -cp "$TMP" PerformancePolicyTest

java --add-modules jdk.httpserver -cp "$TMP" TransportIntegration
