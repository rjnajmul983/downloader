package com.turbofetch.core;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Locale;
/** Public Android APIs via reflection; host tests have no Android runtime. */
public final class RuntimeSignals {
 private static final ThreadLocal<Object> CONTEXT=new ThreadLocal<>();
 private static final ConcurrentHashMap<String,String> LIVE=new ConcurrentHashMap<>();
 private static volatile String last="No HyperSpeed HTTP transfer has run in this process.";
 public static void enter(Object context){CONTEXT.set(context);}public static void exit(){CONTEXT.remove();}static Object context(){return CONTEXT.get();}
 private static Object call(String type,Object obj,String method,Class<?>[] args,Object... values)throws Exception{return Class.forName(type).getMethod(method,args).invoke(obj,values);}
 private static Object service(Object ctx,String name)throws Exception{return call("android.content.Context",ctx,"getSystemService",new Class<?>[]{String.class},name);}
 private static final Class<?>[] NONE=new Class<?>[0];
 public static final class Sample {final int heat;final boolean saver,low;final String network;Sample(int h,boolean s,boolean l,String n){heat=h;saver=s;low=l;network=n;}}
 static Sample sample(Object ctx){int heat=-1;boolean saver=false,low=false;String network="unknown";
  if(ctx!=null){
   try{Object pm=service(ctx,"power");heat=(Integer)call("android.os.PowerManager",pm,"getCurrentThermalStatus",NONE);saver=(Boolean)call("android.os.PowerManager",pm,"isPowerSaveMode",NONE);}catch(Exception ignored){}
   try{Object am=service(ctx,"activity");Class<?> info=Class.forName("android.app.ActivityManager$MemoryInfo");Object mi=info.getConstructor().newInstance();call("android.app.ActivityManager",am,"getMemoryInfo",new Class<?>[]{info},mi);low=info.getField("lowMemory").getBoolean(mi);}catch(Exception ignored){}
   try{Object cm=service(ctx,"connectivity");Object n=call("android.net.ConnectivityManager",cm,"getActiveNetwork",NONE);if(n!=null){Object caps=call("android.net.ConnectivityManager",cm,"getNetworkCapabilities",new Class<?>[]{Class.forName("android.net.Network")},n);if(caps!=null){for(int t:new int[]{4,1,0,3})if((Boolean)call("android.net.NetworkCapabilities",caps,"hasTransport",new Class<?>[]{int.class},t)){network=t==4?"VPN":t==1?"Wi-Fi":t==0?"Cellular":"Ethernet";break;}}}}catch(Exception ignored){}
  }return new Sample(heat,saver,low,network);}
 static void update(Job j,Engine.Control c,Sample s){String text=String.format(Locale.ROOT,"State: %s\nSpeed: %.2f MiB/s\nActive workers: %d / %d\nResource cap: %d\nBuffer: %d KiB\nReceived: %d / %d bytes\nNetwork: %s\nThermal status: %s\nBattery saver: %s\nLow memory: %s\nStorage: %s\nTransport: %s",j.state,j.speed/1048576.0,j.workers,j.workerLimit,c.workerBudget,j.bufferBytes/1024,j.bytes.get(),j.total,s.network,s.heat<0?"Unavailable":Integer.toString(s.heat),s.saver,s.low,j.direct?"Private positional file":"Segment files",c.transport.description());LIVE.put(j.id,text);last=text;}
 static void finish(Job j,Engine.Control c,Sample s){update(j,c,s);LIVE.remove(j.id);}
 public static String report(){return LIVE.isEmpty()?"Last transfer / idle\n\n"+last:String.join("\n\n────────\n\n",LIVE.values());}
}
