package com.turbofetch.app.engine;
import java.util.*;
/** Compile-time ABI mirror of the supplied APK; NEVER package this stub. */
public class DownloadJob {
 public String id="",url="",fileName="download",mimeType="",cookieHeader="",referer="",userAgent="",expectedSha256="",etag="",lastModified="",status="DOWNLOADING",error="",outputUri="",kind="HTTP";
 public boolean adaptive=true,userNamedFile=false;
 public volatile boolean workerOwned=false,serviceOwned=false;
 public volatile long downloadedBytes=0,totalBytes=-1,speedBps=0;
 public volatile int connections=32, speedLimitKiB=0,completedSegments=0,totalSegments=0;
 public final List<Part> parts=new ArrayList<>();
 public static class Part {public long start,end,done;public Part(long a,long b,long c){start=a;end=b;done=c;}}
}
