import com.turbofetch.core.LegacyBridge;
import com.turbofetch.app.engine.DownloadJob;
import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
public class BridgeIntegration {
 static void check(boolean v,String m){if(!v)throw new AssertionError(m);}
 static String sha(byte[] b)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));}
 public static void main(String[] args)throws Exception{
  File root=Files.createTempDirectory("bridge-test").toFile();byte[] payload=new byte[24*1024*1024];new Random(9).nextBytes(payload);
  AtomicBoolean headers=new AtomicBoolean(false);AtomicInteger probeCount=new AtomicInteger();List<String> ranges=Collections.synchronizedList(new ArrayList<>());
  ExecutorService pool=Executors.newCachedThreadPool();HttpServer http=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);http.setExecutor(pool);
  http.createContext("/file",x->{try{String range=x.getRequestHeaders().getFirst("Range");if("session=demo".equals(x.getRequestHeaders().getFirst("Cookie"))&&"https://example.test/".equals(x.getRequestHeaders().getFirst("Referer")))headers.set(true);if(range==null){x.sendResponseHeaders(400,-1);return;}String[] r=range.substring(6).split("-");int a=Integer.parseInt(r[0]),b=Integer.parseInt(r[1]);if(a==0&&b==0)probeCount.incrementAndGet();else ranges.add(range);x.getResponseHeaders().set("ETag","\"test-payload\"");x.getResponseHeaders().set("Content-Range","bytes "+a+"-"+b+"/"+payload.length);x.getResponseHeaders().set("Content-Disposition","attachment; filename=restored.bin");x.getResponseHeaders().set("Content-Type","application/octet-stream");x.sendResponseHeaders(206,b-a+1);try(OutputStream out=x.getResponseBody()){for(int at=a;at<=b;){int n=Math.min(64*1024,b-at+1);out.write(payload,at,n);out.flush();at+=n;try{Thread.sleep(20);}catch(InterruptedException e){break;}}}}catch(IOException ignored){}finally{x.close();}});http.start();
  try{
   DownloadJob j=new DownloadJob();j.id="job1";j.url="http://127.0.0.1:"+http.getAddress().getPort()+"/file";j.connections=4;j.expectedSha256=sha(payload);j.cookieHeader="session=demo";j.referer="https://example.test/";AtomicBoolean stop=new AtomicBoolean();
   boolean paused=false;try{LegacyBridge.download(j,root,x->{if(x.downloadedBytes>=2*1024*1024)stop.set(true);},n->{},stop);}catch(InterruptedIOException e){paused=true;}
   check(paused,"expected pause");long have=j.downloadedBytes;check(have>0&&have<payload.length,"saved progress "+have);check(headers.get(),"original browser request headers missing");check(j.fileName.equals("restored.bin"),"filename metadata missing");
   File ready=LegacyBridge.download(j,root,x->{},n->{},new AtomicBoolean());check(ready.length()==payload.length,"size mismatch");check(sha(Files.readAllBytes(ready.toPath())).equals(j.expectedSha256),"hash mismatch");check(j.downloadedBytes==payload.length,"progress mismatch");
   int before=ranges.size();File again=LegacyBridge.download(j,root,x->{},n->{},new AtomicBoolean());check(again.equals(ready)&&ranges.size()==before,"publication retry redownloaded");System.out.println("PASS legacy ABI bridge pause/reopen/resume, cookie+referer, filename, SHA-256, publication retry; saved="+have);
   j.status="COMPLETED";LegacyBridge.cleanup(root,j);check(!ready.exists(),"completion cleanup failed");System.out.println("PASS original publication cleanup");
   DownloadJob old=new DownloadJob();old.id="old";old.url=j.url;old.totalBytes=1024;old.downloadedBytes=100;old.parts.add(new DownloadJob.Part(0,1023,100));try(RandomAccessFile f=new RandomAccessFile(new File(root,"old.part"),"rw")){f.setLength(1024);}check(LegacyBridge.download(old,root,x->{},n->{},new AtomicBoolean())==null,"old part did not retain original path");boolean guarded=false;try{LegacyBridge.protectLegacy(old,root);}catch(IOException e){guarded=true;}check(guarded&&new File(root,"old.part").length()==1024,"legacy protection failed");System.out.println("PASS legacy partial compatibility and destructive restart protection");
   old.status="FAILED";check(!LegacyBridge.mayClear(old),"partial history deleted");old.downloadedBytes=0;check(LegacyBridge.mayClear(old),"empty failed history not clearable");old.workerOwned=true;check(!LegacyBridge.mayClear(old),"active history deleted");System.out.println("PASS history protection");
  }finally{http.stop(0);pool.shutdownNow();try(var paths=Files.walk(root.toPath())){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}}
 }
}
