# Restoration Ultimate host evidence and open work

Input: Restoration Plus archive. Original APK reconstruction SHA-256: `00fa15ad6fb3b64bc89f1bcb69c7757ba3e64004e7bed742cbe803b6f6ca14fa` (verified against provided original and split parts).

## Actual local tests
- 34 core tests and 6 bridge tests (PASS; JVM, with ABI stubs for original app). The new transport tests validate retry after an injected connection failure, trusted-range routing eligibility, safe host fallback and SHA-256; do not test actual Android transport.
- Patch fixture: six original classes, including three FTP File.delete call replacements. Original DEX audit confirmed FTP REST, Torrent .fastresume and disk flush requests, and stream segment methods; device behavior not verified.
- Benchmark: four runs, same deterministic 64 MiB localhost payload and 32-worker cap, alternating backend order; all SHA-256 checks passed. Segmented runs 9.61 and 9.99 MiB/s (mean 9.80); single-file dynamic runs 10.93 and 10.89 MiB/s (mean 10.91). About 11.3% improvement between modes, not a comparison with the original APK or previous release, nor evidence of HTTP/3 or cellular speed. Time means 6.53s versus 5.87s. Two runs each do not establish broad performance guarantees.

## Unverified Android-specific changes
- Platform HttpEngine and optional dual-network routes need a physical device or supported emulator. Public APIs documented at https://developer.android.com/reference/android/net/http/HttpEngine and https://developer.android.com/reference/android/net/Network. Native HttpEngine can negotiate HTTP/3 if the server/network supports it, but this kit has not verified negotiated protocol. Existing browser authenticated downloads intentionally remain on platform URLConnection.
- Optional dual network requires consent, existing validated Wi-Fi and cellular, no VPN, Wi-Fi-only disabled, trusted checksum and strong ETag. Does not force an additional network or promise aggregation. No data limit/metering feature implemented.
- Original FTP REST mechanism has a newly tested nonempty-partial deletion guard; real FTP transfer, Torrent and HLS/DASH regression still pending. Original modules kept; no new protocol engines claimed.
- Private single-file positional writing is present. MediaStore/SAF direct public destination requires a new durable file-descriptor backend and original export/cancel integration; it is deliberately NOT enabled to avoid data loss. Existing public copy remains.
- Predictive controller is a network/size/profile heuristic plus observed-throughput feedback; more sophisticated latency/storage prediction remains open.
- API 35/36 emulator launcher smoke and optional scanner UI harness prepared. Actual APK assembly, signing, Android runtime and full device regression have not been performed locally. SDK download DNS failure persists.

## Release gates
Run CI build/signing, verify original feature preservation, run emulator smoke and scanner regression, then controlled real-device HTTP/FTP/Torrent/HLS/DASH, actual HTTP/3 server and dual-network tests, and compare speed on identical network/server. Do not call preview stable until complete.

## Additional 5 GiB acceptance test
The latest direct/dynamic backend was tested on a generated 5 GiB resource. Paused after 2,159,673,291 durable bytes; reopened the store; resumed with 32-worker cap; no committed ranges re-requested; correct 5,368,709,120-byte final length and SHA-256 `5fe9efe001aab0eb708687a5ffe68a9702f8200ecb2fd546732b950379347206`. Elapsed 24.6s excluding generation of expected checksum. This is a local JVM test, not a phone test.
