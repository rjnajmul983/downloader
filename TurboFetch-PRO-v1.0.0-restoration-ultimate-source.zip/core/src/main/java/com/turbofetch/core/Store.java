package com.turbofetch.core;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;

/** Independent job records avoid rewriting the complete history on each progress tick. */
public final class Store {
    private final File root;
    private final LinkedHashMap<String,Job> jobs=new LinkedHashMap<>();
    public Store(File root) throws IOException {
        this.root=root;if(!root.isDirectory()&&!root.mkdirs())throw new IOException("Cannot create job storage");
        File[] dirs=root.listFiles();if(dirs==null)throw new IOException("Cannot read job storage");
        Arrays.sort(dirs,Comparator.comparingLong(File::lastModified).reversed());
        for(File d:dirs)if(d.isDirectory()&&new File(d,"job.properties").exists()){
            try{Job j=Job.load(d);if(j.state!=Job.State.COMPLETED)j.recoverAll();jobs.put(j.id,j);}
            catch(Exception e){System.err.println("Unreadable job retained: "+d.getName()+" "+e.getClass().getSimpleName());}
        }
    }
    public synchronized List<Job> all(){return new ArrayList<>(jobs.values());}
    public synchronized Job get(String id){return jobs.get(id);}
    public static void validate(String url) throws IOException {
        try{URI u=new URI(url);if(!("https".equalsIgnoreCase(u.getScheme())||"http".equalsIgnoreCase(u.getScheme()))||u.getHost()==null||u.getUserInfo()!=null)throw new IOException("Only HTTP(S) URLs without embedded credentials are supported");}
        catch(URISyntaxException e){throw new IOException("Invalid URL",e);}
    }
    public static String clean(String s){s=s.replaceAll("[\\p{Cntrl}/\\\\:*?\"<>|]","_").trim();if(s.equals(".")||s.equals("..")||s.isEmpty())s="download";return s.length()>180?s.substring(0,180):s;}
    public synchronized Job add(String url,String name,int count,String hash,String agent) throws IOException {
        validate(url);if(hash!=null&&!hash.isEmpty()&&!hash.matches("(?i)[0-9a-f]{64}"))throw new IOException("SHA-256 must contain 64 hexadecimal characters");
        if(name==null||name.trim().isEmpty()){String path=URI.create(url).getPath();name=path==null?"download":path.substring(path.lastIndexOf('/')+1);}
        String id=UUID.randomUUID().toString();File dir=new File(root,id);if(!dir.mkdir())throw new IOException("Cannot create job");
        Job j=new Job(dir,id,url,clean(name));j.connections=Math.max(1,Math.min(32,count));j.sha256=hash==null?"":hash.toLowerCase(Locale.ROOT);j.userAgent=agent==null?"":agent;
        j.save();jobs.put(id,j);return j;
    }
    public synchronized void delete(Job j) throws IOException {
        if(j.inFlight||j.active()||(j.state==Job.State.QUEUED||j.state==Job.State.WAITING_NETWORK))throw new IOException("Pause job first");
        // Delete manifest first, so a partially failed cleanup cannot resurrect history.
        Files.deleteIfExists(new File(j.dir,"job.properties").toPath());jobs.remove(j.id);
        File[] files=j.dir.listFiles();if(files!=null)for(File f:files)Files.deleteIfExists(f.toPath());Files.deleteIfExists(j.dir.toPath());
    }
    public synchronized int clearCompleted() throws IOException {int n=0;for(Job j:all())if(!j.inFlight&&j.state==Job.State.COMPLETED){delete(j);n++;}return n;}
    public synchronized int clearCompletedBefore(long cutoff)throws IOException{int n=0;for(Job j:all())if(!j.inFlight&&j.state==Job.State.COMPLETED&&j.completedAt>0&&j.completedAt<cutoff){delete(j);n++;}return n;}
    public synchronized int clearFailedWithoutData() throws IOException {int n=0;for(Job j:all())if(!j.inFlight&&j.state==Job.State.FAILED&&j.bytes.get()==0&&j.output.isEmpty()){delete(j);n++;}return n;}
    public synchronized void restart(Job j) throws IOException {
        if(j.inFlight||j.active()||(j.state==Job.State.QUEUED||j.state==Job.State.WAITING_NETWORK)||j.state==Job.State.COMPLETED||!j.output.isEmpty())throw new IOException("Cannot restart this job; pending output must be resolved first");
        j.removeParts();j.resetGeometry();j.partCount=0;j.total=-1;j.blockSize=0;j.etag="";j.modified="";j.ranged=false;j.bytes.set(0);j.error="";j.state=Job.State.QUEUED;j.recoverAutomatically=false;j.save();
    }
    public synchronized void replaceUrl(Job j,String url) throws IOException {
        validate(url);if(j.inFlight||j.active()||(j.state==Job.State.QUEUED||j.state==Job.State.WAITING_NETWORK)||j.state==Job.State.COMPLETED)throw new IOException("Pause first");
        URI old=URI.create(j.url), next=URI.create(url);
        if(j.bytes.get()>0&&(!Objects.equals(old.getHost(),next.getHost())||!Objects.equals(old.getScheme(),next.getScheme())||old.getPort()!=next.getPort()||!Objects.equals(old.getPath(),next.getPath()))&&j.sha256.isEmpty())throw new IOException("Different resource requires expected SHA-256 to protect file integrity");
        j.url=url;j.error="";j.state=Job.State.PAUSED;j.recoverAutomatically=false;j.save();
    }
}
