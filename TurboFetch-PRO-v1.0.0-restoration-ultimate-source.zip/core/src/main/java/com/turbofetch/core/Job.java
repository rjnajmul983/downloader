package com.turbofetch.core;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/** One persistent job; each range has its own durable byte checkpoint. */
public final class Job {
    public enum State { QUEUED, WAITING_NETWORK, RUNNING, PAUSING, PAUSED, FAILED, NEEDS_RESTART, FINALIZING, COMPLETED }
    public final String id;
    public final File dir;
    public volatile String url, name, etag="", modified="", error="", output="", sha256="", userAgent="";
    public volatile long total=-1, blockSize=0, completedAt=0;
    public volatile int connections=32, partCount=0;
    public volatile boolean ranged=false, direct=false;
    private final Map<Integer,long[]> ranges=new HashMap<>();
    public File directFile(){return new File(dir,"part-direct.data");}
    public File storage(int n){return direct?directFile():data(n);}
    public long position(int n,long offset){return direct?start(n)+offset:offset;}
    public synchronized void resetGeometry(){ranges.clear();direct=false;}
    public synchronized int[] orderedParts(){Integer[] ids=new Integer[partCount];for(int i=0;i<ids.length;i++)ids[i]=i;Arrays.sort(ids,Comparator.comparingLong(this::start));return Arrays.stream(ids).mapToInt(Integer::intValue).toArray();}
    public synchronized int split(int n,long committed,long leftSize) throws IOException {
        long begin=start(n),old=size(n);if(!ranged||partCount>=8192||leftSize<=committed||leftSize>=old)return -1;
        int next=partCount;long[] prior=ranges.get(n);
        ranges.put(n,new long[]{begin,leftSize});ranges.put(next,new long[]{begin+leftSize,old-leftSize});partCount++;
        try{save();}catch(IOException e){partCount--;ranges.remove(next);if(prior==null)ranges.remove(n);else ranges.put(n,prior);throw e;}return next;
    }
    public synchronized void validateGeometry() throws IOException {
        if(partCount<0||partCount>8192)throw new IOException("Invalid part count");if(!ranged)return;if(total<=0||blockSize<=0||partCount==0)throw new IOException("Invalid ranged job geometry");long pos=0;for(int n:orderedParts()){long len=size(n);if(start(n)!=pos||len<=0||len>total-pos)throw new IOException("Invalid range ledger");pos+=len;}if(pos!=total)throw new IOException("Incomplete range ledger");
    }
    public volatile State state=State.QUEUED;
    public final AtomicLong bytes=new AtomicLong();
    public volatile long speed=0;
    public volatile int workers=0,workerLimit=0,bufferBytes=128*1024;
    public volatile boolean recoverAutomatically=false,inFlight=false;
    Job(File dir, String id, String url, String name) { this.dir=dir;this.id=id;this.url=url;this.name=name; }
    public File data(int n) { return new File(dir,"part-"+n+".data"); }
    public File checkpoint(int n) { return new File(dir,"part-"+n+".commit"); }
    public synchronized long start(int n) { long[] r=ranges.get(n);return r!=null?r[0]:ranged ? n*blockSize : 0; }
    public synchronized long size(int n) { long[] r=ranges.get(n);return r!=null?r[1]:total<0 ? -1 : ranged ? Math.min(blockSize,total-start(n)) : total; }
    public boolean hasValidator(){ return !etag.isEmpty() || !modified.isEmpty(); }
    public boolean active(){ return state==State.RUNNING||state==State.PAUSING||state==State.FINALIZING; }
    public boolean terminal(){ return state==State.COMPLETED||state==State.FAILED||state==State.NEEDS_RESTART; }
    static void atomicProperties(File dest, Properties p) throws IOException {
        File tmp=new File(dest.getPath()+".tmp");
        try(FileOutputStream out=new FileOutputStream(tmp)){p.store(out,null);out.getFD().sync();}
        move(tmp,dest);
    }
    static void move(File from, File to) throws IOException {
        // Same directory: require atomic replacement instead of risking a torn checkpoint.
        Files.move(from.toPath(),to.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
    }
    public synchronized void save() throws IOException {
        Properties p=new Properties();
        p.setProperty("id",id);p.setProperty("url",url);p.setProperty("name",name);
        p.setProperty("etag",etag);p.setProperty("modified",modified);p.setProperty("error",error);
        p.setProperty("output",output);p.setProperty("sha256",sha256);p.setProperty("userAgent",userAgent);
        p.setProperty("total",Long.toString(total));p.setProperty("blockSize",Long.toString(blockSize));
        p.setProperty("completedAt",Long.toString(completedAt));p.setProperty("connections",Integer.toString(connections));
        p.setProperty("partCount",Integer.toString(partCount));p.setProperty("ranged",Boolean.toString(ranged));
        p.setProperty("recoverAutomatically",Boolean.toString(recoverAutomatically));
        p.setProperty("direct",Boolean.toString(direct));for(Map.Entry<Integer,long[]> e:ranges.entrySet())p.setProperty("range."+e.getKey(),e.getValue()[0]+":"+e.getValue()[1]);
        p.setProperty("state",state.name());p.setProperty("bytes",Long.toString(bytes.get()));
        atomicProperties(new File(dir,"job.properties"),p);
    }
    static Job load(File dir) throws IOException {
        Properties p=new Properties();try(FileInputStream in=new FileInputStream(new File(dir,"job.properties"))){p.load(in);}
        Job j=new Job(dir,dir.getName(),p.getProperty("url"),p.getProperty("name","download"));
        j.etag=p.getProperty("etag","");j.modified=p.getProperty("modified","");j.error=p.getProperty("error","");
        j.output=p.getProperty("output","");j.sha256=p.getProperty("sha256","");j.userAgent=p.getProperty("userAgent","");
        j.total=Long.parseLong(p.getProperty("total","-1"));j.blockSize=Long.parseLong(p.getProperty("blockSize","0"));
        j.completedAt=Long.parseLong(p.getProperty("completedAt","0"));j.connections=Integer.parseInt(p.getProperty("connections","8"));
        j.partCount=Integer.parseInt(p.getProperty("partCount","0"));j.ranged=Boolean.parseBoolean(p.getProperty("ranged","false"));
        j.recoverAutomatically=Boolean.parseBoolean(p.getProperty("recoverAutomatically",Boolean.toString("WAITING_NETWORK".equals(p.getProperty("state")))));
        j.direct=Boolean.parseBoolean(p.getProperty("direct","false"));for(String k:p.stringPropertyNames())if(k.startsWith("range.")){int i=Integer.parseInt(k.substring(6));String[] a=p.getProperty(k).split(":");if(i<0||i>=j.partCount||a.length!=2)throw new IOException("Invalid ledger entry");j.ranges.put(i,new long[]{Long.parseLong(a[0]),Long.parseLong(a[1])});}j.validateGeometry();
        j.state=State.valueOf(p.getProperty("state","PAUSED"));j.bytes.set(Long.parseLong(p.getProperty("bytes","0")));
        if(j.active()){j.state=j.recoverAutomatically?State.WAITING_NETWORK:State.PAUSED;j.error=j.recoverAutomatically?"Interrupted; waiting to recover saved bytes.":"Interrupted; tap Resume to recover saved bytes.";j.save();}
        return j;
    }
    /** Recover only bytes whose data was synced BEFORE publishing the checkpoint. */
    public long recover(int n) throws IOException {
        File f=storage(n), c=checkpoint(n);long actual=direct?Math.max(0,f.length()-start(n)):f.length(), committed=0;
        if(c.exists()){try(DataInputStream in=new DataInputStream(new FileInputStream(c))){committed=in.readLong();}}
        long limit=size(n);long safe=Math.max(0,Math.min(committed,actual));if(limit>=0)safe=Math.min(safe,limit);
        if(!direct&&actual!=safe){try(RandomAccessFile r=new RandomAccessFile(f,"rw")){r.setLength(safe);r.getFD().sync();}}
        if(committed!=safe) commit(n,safe);
        return safe;
    }
    public void commit(int n,long length) throws IOException {
        File dest=checkpoint(n), tmp=new File(dest.getPath()+".tmp");
        try(FileOutputStream f=new FileOutputStream(tmp);DataOutputStream d=new DataOutputStream(f)){d.writeLong(length);d.flush();f.getFD().sync();}
        move(tmp,dest);
    }
    public synchronized long recoverAll() throws IOException {long sum=0;for(int n=0;n<partCount;n++)sum+=recover(n);bytes.set(sum);return sum;}
    public synchronized void removeParts() throws IOException {
        File[] files=dir.listFiles();if(files==null)throw new IOException("Cannot list job directory");
        for(File f:files)if(f.getName().startsWith("part-"))Files.deleteIfExists(f.toPath());
    }
}
