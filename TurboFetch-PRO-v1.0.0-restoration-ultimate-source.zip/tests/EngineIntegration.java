import com.turbofetch.core.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Actual localhost HTTP transfers; no internet, Android runtime, or JUnit required. */
public final class EngineIntegration {
    static int passed;
    static void require(boolean b,String why){if(!b)throw new AssertionError(why);}
    static void pass(String s){passed++;System.out.println("PASS "+s);}
    static String hash(byte[] data)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));}
    static byte[] read(File f)throws Exception{return Files.readAllBytes(f.toPath());}
    static class Server implements AutoCloseable {
        final byte[] data;final HttpServer http;final ExecutorService executor=Executors.newCachedThreadPool();
        volatile int delayMillis=2;
        volatile boolean ranges=true,slow=true,malformed=false,refuseParts=false,unknown=false;volatile String etag="\"v1\"";
        final List<long[]> requests=Collections.synchronizedList(new ArrayList<>());
        Server(int size)throws Exception{data=new byte[size];new Random(81).nextBytes(data);http=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);http.setExecutor(executor);http.createContext("/file",this::serve);http.start();}
        String url(){return "http://127.0.0.1:"+http.getAddress().getPort()+"/file";}
        void serve(HttpExchange x)throws IOException{
            String r=x.getRequestHeaders().getFirst("Range"),validator=x.getRequestHeaders().getFirst("If-Range");int start=0,end=data.length-1,status=200;
            x.getResponseHeaders().set("ETag",etag);
            if(r!=null&&ranges&&(validator==null||validator.equals(etag))&&!(refuseParts&&!r.equals("bytes=0-0"))){
                String[] p=r.substring(6).split("-",-1);start=Integer.parseInt(p[0]);end=p[1].isEmpty()?end:Math.min(end,Integer.parseInt(p[1]));
                if(start>=data.length){x.getResponseHeaders().set("Content-Range","bytes */"+data.length);x.sendResponseHeaders(416,-1);x.close();return;}
                status=206;x.getResponseHeaders().set("Content-Range","bytes "+(malformed&&!r.equals("bytes=0-0")?start+1:start)+"-"+end+"/"+data.length);requests.add(new long[]{start,end});
            }
            int len=end-start+1;x.sendResponseHeaders(status,unknown&&status==200?0:len==0?-1:len);
            try(OutputStream out=x.getResponseBody()){for(int i=start;i<=end;i+=16384){out.write(data,i,Math.min(16384,end-i+1));if(slow)try{Thread.sleep(delayMillis);}catch(InterruptedException e){break;}}}catch(IOException ignored){}finally{x.close();}
        }
        public void close(){http.stop(0);executor.shutdownNow();}
    }
    static Engine.Publisher publisher(File f){return (j,c)->{try(FileOutputStream out=new FileOutputStream(f)){Engine.copyParts(j,out,c);out.getFD().sync();}return f.toString();};}
    static long pause(Job j,File out)throws Exception{
        Engine.Control c=new Engine.Control();Thread t=new Thread(()->new Engine().run(j,c,publisher(out)));t.start();long deadline=System.nanoTime()+10_000_000_000L;while(j.bytes.get()<2_000_000&&t.isAlive()&&System.nanoTime()<deadline)Thread.sleep(10);c.pause();t.join(20000);require(!t.isAlive(),"pause timed out");require(j.state==Job.State.PAUSED,"pause state: "+j.state+" "+j.error);require(j.bytes.get()>0&&j.bytes.get()<j.total,"partial data expected");return j.bytes.get();}
    public static void main(String[] args)throws Exception{
        File root=Files.createTempDirectory("turbo-test-").toFile(),out=new File(root,"out.bin");
        try(Server s=new Server(24*1024*1024)){
            Store store=new Store(new File(root,"jobs"));Job j=store.add(s.url(),"big.bin",8,hash(s.data),"");long paused=pause(j,out);String id=j.id;
            Store reopened=new Store(new File(root,"jobs"));j=reopened.get(id);require(j.bytes.get()==paused,"lost durable bytes on reopen");long[] offsets=new long[j.partCount];for(int n=0;n<offsets.length;n++)offsets[n]=j.recover(n);
            int tail=-1;for(int n=0;n<offsets.length;n++)if(offsets[n]>0&&offsets[n]<j.size(n)){tail=n;break;}
            if(tail<0)for(int n=0;n<offsets.length;n++)if(offsets[n]==0){tail=n;break;}
            require(tail>=0,"no partial range");try(FileOutputStream f=new FileOutputStream(j.data(tail),true)){f.write(new byte[500]);f.getFD().sync();}
            reopened=new Store(new File(root,"jobs"));j=reopened.get(id);require(j.bytes.get()==paused,"uncommitted crash tail counted");require(j.data(tail).length()==offsets[tail],"uncommitted tail not truncated");pass("checkpoint recovery after process reopen + uncommitted tail");
            s.requests.clear();s.slow=false;new Engine().run(j,new Engine.Control(),publisher(out));require(j.state==Job.State.COMPLETED,"resume failed: "+j.error);require(Arrays.equals(read(out),s.data),"corrupted final file");
            for(long[] range:s.requests){if(range[0]==0&&range[1]==0)continue;int n=(int)(range[0]/j.blockSize);require(range[0]>=j.start(n)+offsets[n],"redownloaded committed bytes");}
            pass("multi-segment pause/resume retains "+paused+" bytes, no committed ranges re-requested, SHA-256 exact");
            require(reopened.clearCompleted()==1,"history deletion count");require(out.exists(),"history deleted output");require(new Store(new File(root,"jobs")).all().isEmpty(),"deleted history resurrected");pass("completed history removal persists and keeps output");
            s.slow=true;Job changed=reopened.add(s.url(),"changed.bin",8,"","");long saved=pause(changed,out);s.etag="\"v2\"";s.slow=false;new Engine().run(changed,new Engine.Control(),publisher(out));require(changed.state==Job.State.NEEDS_RESTART&&changed.bytes.get()==saved,"changed ETag lost progress: "+changed.error);pass("changed ETag blocks unsafe resume without deleting bytes");
            s.etag="\"v1\"";s.slow=true;Job rejected=reopened.add(s.url(),"refused.bin",4,"","");saved=pause(rejected,out);s.slow=false;s.refuseParts=true;new Engine().run(rejected,new Engine.Control(),publisher(out));require(rejected.state==Job.State.NEEDS_RESTART&&rejected.bytes.get()==saved,"HTTP 200 range rejection not safe: "+rejected.error);s.refuseParts=false;pass("HTTP 200 instead of 206 preserves partial data");
            s.malformed=true;Job malformed=reopened.add(s.url(),"malformed.bin",4,"","");new Engine().run(malformed,new Engine.Control(),publisher(out));require(malformed.state==Job.State.NEEDS_RESTART&&malformed.bytes.get()==0,"bad range accepted");s.malformed=false;pass("malformed Content-Range rejected before writing");
            s.ranges=false;s.slow=true;Job plain=reopened.add(s.url(),"plain.bin",8,"","");saved=pause(plain,out);s.slow=false;new Engine().run(plain,new Engine.Control(),publisher(out));require(plain.state==Job.State.NEEDS_RESTART&&plain.bytes.get()==saved,"non-resumable silently restarted");pass("non-range server does not silently restart");
            reopened.restart(plain);new Engine().run(plain,new Engine.Control(),publisher(out));require(plain.state==Job.State.COMPLETED&&Arrays.equals(read(out),s.data),"explicit restart failed");pass("explicit confirmed restart works for non-range server");
            s.unknown=true;Job unknown=reopened.add(s.url(),"unknown.bin",8,hash(s.data),"");new Engine().run(unknown,new Engine.Control(),publisher(out));require(unknown.state==Job.State.COMPLETED&&unknown.total==s.data.length&&Arrays.equals(read(out),s.data),"unknown length transfer failed "+unknown.error);pass("unknown content length streams to EOF with hash verification");
            Job invalidHash=reopened.add(s.url(),"bad-hash.bin",8,"0".repeat(64),"");new Engine().run(invalidHash,new Engine.Control(),publisher(out));require(invalidHash.state==Job.State.NEEDS_RESTART,"wrong SHA-256 accepted");pass("SHA-256 mismatch blocks publication");
            Job failed=reopened.add(s.url(),"failed.bin",4,"","");failed.state=Job.State.FAILED;failed.save();require(reopened.clearFailedWithoutData()==1,"failed cleanup");require(reopened.get(changed.id)!=null,"partial job deleted during clear");pass("failed history cleanup protects resumable records");
        }
        try(Server z=new Server(0)){Store st=new Store(new File(root,"empty-jobs"));Job j=st.add(z.url(),"empty.bin",4,hash(z.data),"");new Engine().run(j,new Engine.Control(),publisher(out));require(j.state==Job.State.COMPLETED&&out.length()==0,"empty file: "+j.error);pass("zero-byte file via HTTP 416 bytes */0");}
        System.out.println("TOTAL PASSED: "+passed);
        try(java.util.stream.Stream<Path> walk=Files.walk(root.toPath())){walk.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}
    }
}
