import com.turbofetch.core.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public final class HyperSpeedIntegration {
    static final long M=1024*1024L;static int count;
    static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
    static void pass(String s){System.out.println("PASS HYPERSPEED "+s);count++;}
    static Engine.Control auto(){Engine.Control c=new Engine.Control();c.dynamicRanges=true;c.directStorage=true;return c;}
    static List<long[]> committed(Job j)throws Exception{List<long[]> a=new ArrayList<>();for(int n=0;n<j.partCount;n++){long r=j.recover(n);if(r>0)a.add(new long[]{j.start(n),j.start(n)+r-1});}return a;}
    static void noOverlap(List<long[]> requests,List<long[]> old){for(long[] r:requests){if(r[0]==0&&r[1]==0)continue;for(long[] p:old)check(r[0]>p[1]||r[1]<p[0],"Previously committed byte requested: "+Arrays.toString(r)+" overlaps "+Arrays.toString(p));}}
    public static void main(String[] args)throws Exception{
        File root=Files.createTempDirectory("turbo-hyper-").toFile(),out=new File(root,"output.bin");
        try(EngineIntegration.Server s=new EngineIntegration.Server(32*(int)M)){
            File jobs=new File(root,"jobs");Store st=new Store(jobs);String hash=EngineIntegration.hash(s.data);Job j=st.add(s.url(),"direct.bin",4,hash,"");
            Engine.Control c=auto();final Job first=j;Thread t=new Thread(()->new Engine().run(first,c,EngineIntegration.publisher(out)));t.start();long end=System.nanoTime()+15_000_000_000L;while(j.bytes.get()<3*M&&t.isAlive()&&System.nanoTime()<end)Thread.sleep(5);c.pause();t.join(20000);
            check(!t.isAlive()&&j.state==Job.State.PAUSED&&j.direct&&j.bytes.get()>0&&j.bytes.get()<j.total,"direct pause "+j.error);check(j.directFile().exists(),"single file missing");for(int n=0;n<j.partCount;n++)check(!j.data(n).exists(),"individual payload exists");pass("single-file positional backend and durable pause");
            long saved=j.bytes.get();String id=j.id;st=new Store(jobs);j=st.get(id);check(j.direct&&j.bytes.get()==saved,"direct reopen");List<long[]> old=committed(j);int hole=-1;for(int n=0;n<j.partCount;n++)if(j.recover(n)<j.size(n)){hole=n;break;}check(hole>=0,"expected hole");try(RandomAccessFile f=new RandomAccessFile(j.directFile(),"rw")){f.seek(j.start(hole)+j.recover(hole));f.write(123);f.getFD().sync();}st=new Store(jobs);j=st.get(id);check(j.bytes.get()==saved,"uncommitted direct byte counted");pass("sparse/high-water file does not count uncommitted data");
            int split=-1;long at=0;for(int n=0;n<j.partCount;n++){long a=j.recover(n);if(j.size(n)-a>=2*M){split=n;at=a;break;}}check(split>=0,"need unfinished range");int prev=j.partCount;check(j.split(split,at,at+(j.size(split)-at)/2)==prev,"split failed");j.validateGeometry();st=new Store(jobs);j=st.get(id);check(j.partCount==prev+1&&j.bytes.get()==saved,"split ledger reopen");j.validateGeometry();pass("persistent split ledger preserves coverage and committed progress");
            s.requests.clear();s.slow=false;j.connections=8;j.save();new Engine().run(j,auto(),EngineIntegration.publisher(out));check(j.state==Job.State.COMPLETED&&Arrays.equals(EngineIntegration.read(out),s.data),"direct split resume integrity "+j.error);noOverlap(s.requests,old);pass("direct split resume requests no committed ranges and verifies SHA-256");
            // Force an actual live tail split with a valid legacy 32 MiB one-range job containing a committed byte.
            Job live=st.add(s.url(),"live.bin",4,hash,"");live.total=s.data.length;live.blockSize=live.total;live.partCount=1;live.ranged=true;live.etag=s.etag;live.state=Job.State.PAUSED;
            try(RandomAccessFile f=new RandomAccessFile(live.data(0),"rw")){f.write(s.data[0]);f.getFD().sync();}live.commit(0,1);live.save();s.slow=true;s.delayMillis=1;s.requests.clear();new Engine().run(live,auto(),EngineIntegration.publisher(out));check(live.state==Job.State.COMPLETED&&live.partCount>1&&Arrays.equals(EngineIntegration.read(out),s.data),"live split failed: "+live.error+" parts="+live.partCount);live.validateGeometry();noOverlap(s.requests,List.of(new long[]{0,0}));pass("live cooperative splitting of unfinished legacy range, ordered publication and exact SHA-256");
            s.ranges=false;s.slow=false;Job fallback=st.add(s.url(),"fallback.bin",32,hash,"");new Engine().run(fallback,auto(),EngineIntegration.publisher(out));check(!fallback.direct&&fallback.state==Job.State.COMPLETED&&Arrays.equals(EngineIntegration.read(out),s.data),"single stream fallback");pass("non-range server falls back to existing streaming storage");
            check(st.clearCompleted()==3&&out.exists(),"cleanup lost public file");pass("history cleanup after direct and split jobs retains published files");
        }finally{try(var walk=Files.walk(root.toPath())){walk.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}}
        // One origin's Retry-After must delay a separate job too, not just the failing worker.
        File cool=Files.createTempDirectory("turbo-cool-").toFile();
        java.util.concurrent.atomic.AtomicLong limitedAt=new java.util.concurrent.atomic.AtomicLong(), nextAt=new java.util.concurrent.atomic.AtomicLong();
        try(EngineIntegration.Server s=new EngineIntegration.Server(1024*1024){
            @Override void serve(com.sun.net.httpserver.HttpExchange x)throws IOException{
                long now=System.nanoTime();if(limitedAt.compareAndSet(0,now)){x.getResponseHeaders().set("Retry-After","2");x.sendResponseHeaders(429,-1);x.close();return;}nextAt.compareAndSet(0,now);super.serve(x);
            }
        }){
            s.slow=false;Store st=new Store(new File(cool,"jobs"));Job a=st.add(s.url(),"a.bin",1,"",""),b=st.add(s.url(),"b.bin",1,"","");
            Thread one=new Thread(()->new Engine().run(a,auto(),EngineIntegration.publisher(new File(cool,"a"))));one.start();long until=System.nanoTime()+5_000_000_000L;while(limitedAt.get()==0&&System.nanoTime()<until)Thread.sleep(10);check(limitedAt.get()!=0,"rate limit not observed");Thread.sleep(350);
            new Engine().run(b,auto(),EngineIntegration.publisher(new File(cool,"b")));one.join(10000);check(a.state==Job.State.COMPLETED&&b.state==Job.State.COMPLETED,"cooldown recovery failed");check(nextAt.get()-limitedAt.get()>=1_800_000_000L,"origin cooldown not shared");pass("Retry-After cooldown shared by independent jobs");
        }finally{try(var walk=Files.walk(cool.toPath())){walk.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}}
        System.out.println("HYPERSPEED TOTAL PASSED: "+count);
    }
}
