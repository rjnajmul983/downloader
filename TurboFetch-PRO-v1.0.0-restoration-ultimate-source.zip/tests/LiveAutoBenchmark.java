import com.turbofetch.core.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
/** Controlled per-stream limited HTTP server. Exercises actual adaptive worker growth. */
public final class LiveAutoBenchmark {
    public static void main(String[] args)throws Exception{
        File root=Files.createTempDirectory("auto-live-").toFile();int mib=128;
        try(EngineIntegration.Server s=new EngineIntegration.Server(mib*1024*1024)){
            s.delayMillis=16;String expected=EngineIntegration.hash(s.data);
            for(int cap:new int[]{8,32}){
                Store store=new Store(new File(root,"jobs-"+cap));Job j=store.add(s.url(),"test.bin",cap,expected,"");File out=new File(root,"out.bin");Engine.Control c=new Engine.Control();Thread t=new Thread(()->new Engine().run(j,c,EngineIntegration.publisher(out)));long start=System.nanoTime();t.start();int peak=0;
                while(t.isAlive()){peak=Math.max(peak,j.workers);Thread.sleep(50);}t.join();double sec=(System.nanoTime()-start)/1e9;
                EngineIntegration.require(j.state==Job.State.COMPLETED&&out.length()==s.data.length,"Live transfer failed: "+j.error);
                EngineIntegration.require(expected.equals(EngineIntegration.hash(Files.readAllBytes(out.toPath()))),"Wrong data");
                System.out.printf(Locale.US,"Cap %d: peak %d actual workers, %.2fs, %.2f MiB/s, SHA-256 OK%n",cap,peak,sec,mib/sec);
                if(cap==32)EngineIntegration.require(peak>8,"Auto engine did not grow above eight workers under controlled per-stream ceiling");
            }
            System.out.println("PASS live Smart Auto above 8 workers; synthetic localhost, not ISP comparison");
        }finally{try(java.util.stream.Stream<Path> walk=Files.walk(root.toPath())){walk.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}}
    }
}
