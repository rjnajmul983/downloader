import com.turbofetch.core.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
/** Compare legacy-compatible and new backends on the same deterministic origin. */
public final class HyperBenchmark {
    public static void main(String[] args)throws Exception{
        File root=Files.createTempDirectory("turbo-hyper-bench-").toFile();int mib=64;
        try(EngineIntegration.Server s=new EngineIntegration.Server(mib*1024*1024)){
            s.delayMillis=8;String hash=EngineIntegration.hash(s.data);
            for(int run=0;run<2;run++)for(int order=0;order<2;order++){
                boolean direct=(order+run)%2==1;Store st=new Store(new File(root,"jobs-"+run+"-"+order));Job j=st.add(s.url(),"file.bin",32,hash,"");File out=new File(root,"out.bin");Engine.Control c=new Engine.Control();c.dynamicRanges=direct;c.directStorage=direct;long start=System.nanoTime();new Engine().run(j,c,EngineIntegration.publisher(out));double sec=(System.nanoTime()-start)/1e9;
                EngineIntegration.require(j.state==Job.State.COMPLETED&&Arrays.equals(EngineIntegration.read(out),s.data),"benchmark integrity "+j.error);
                System.out.printf(Locale.US,"Run %d %s: %.2f sec, %.2f MiB/s, %d final ranges, SHA-256 OK%n",run+1,direct?"HyperSpeed direct+dynamic":"legacy-compatible segmented",sec,mib/sec,j.partCount);
            }
        }finally{try(var walk=Files.walk(root.toPath())){walk.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}}
    }
}
