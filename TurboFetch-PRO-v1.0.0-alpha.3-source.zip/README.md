# TurboFetch PRO v1.0.0-alpha.3 — HyperSpeed Ultimate (incremental alpha)

Upgrades the actual supplied alpha.2 project, preserving package `com.turbofetch.app.pro`, Java 17, SDK 35 and the existing job schema for older downloads. Version code 10002. Default HyperSpeed Auto (up to 32 logical workers, one active file) requires no ordinary performance setup. New supported ranged downloads use a private single-file positional-write backend and live cooperative range splitting; existing partials keep their storage backend. This is an alpha, not a production-ready release.

## Phone-only build
Upload `TurboFetch-PRO-v1.0.0-alpha.3-source.zip` unchanged to a GitHub repository root and replace `.github/workflows/android-build.yml` with the separate workflow. Actions → TurboFetch PRO - Build APK → Run workflow. After success, download the `TurboFetch-PRO-v1.0.0-alpha.3-APK` artifact, extract app-debug.apk and verify checksum if desired. Older ZIPs can remain; do not mix extracted project and alpha.3 ZIP. JDK 17, Gradle 8.11.1, SDK 35. Optional large_test runs two 5 GiB host tests sequentially. Local Android SDK/Gradle setup failed due to DNS; actual Android compile, lint and phone tests remain pending. No APK or wrapper binary fabricated.

## Actual changes
- Existing 20 host tests retained; expanded tests cover direct private storage, sparse checkpoint recovery, persistent/live split ledger, exact hash and shared Retry-After.
- Cooperative split only when workers are available, original owner syncs and checkpoints before publishing new geometry. Range IDs remain stable; publication sorted by byte offset. No overlapping writes. A split may abandon read-ahead/uncommitted data, so wire-level request overlap is possible.
- Private single-file positional writes for new identifiable ranged resources; fallback to segment files at initial backend selection. Checkpoints remain authoritative, not file length. Existing legacy partials stay segmented. Android MediaStore publication still copies the payload; peak disk can remain ~2x. This is NOT public direct-to-disk/zero-copy.
- Active HTTP connections tracked for best-effort asynchronous disconnect when pausing. Existing bounded timeouts and retry behavior retained. Per-origin shared Retry-After gate applies to future requests in the same process (not already in-flight or across reboot).
- Existing learned profiles, adaptive worker count and buffer selection, network recovery, thermal limits, history management and basic browser retained. Small-file initial worker preference reduced to one for <4 MiB in HyperSpeed mode. Actual device behavior pending.
- Workflow updated for exact alpha.3 archive, core tests, optional large tests, Android unit test task, APK checksum, lint/report artifacts. Owner-controlled signing supported as before.

## Tests
```
bash tools/test-core.sh
bash tools/test-extra.sh large
bash tools/test-extra.sh large-direct
bash tools/test-extra.sh hyper
```
Reports in docs. All measurements use local controlled servers and are not mobile speed guarantees.

## Limitations
Still missing: public destination direct writes, HTTP/2 transport replacement, HTTP/3/QUIC, simultaneous Wi-Fi+mobile data, full predictive learning redesign, per-range trusted checksum/repair, advanced diagnostics, automatic reboot recovery, premium browser/protocols (torrent/FTP/HLS/DASH), media/archive tools, full localization and other premium features. Do not advertise these as implemented. No paid API, no ads, no root. Non-range or changed resources cannot safely resume; saved partials are retained and explicit restart required. Never uninstall an app with important unfinished files to work around incompatible signatures. Alpha.3 schema is intended for forward upgrades; downgrading after new dynamic/direct jobs is unsafe.
