package com.turbofetch.app.pro;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;
import com.turbofetch.core.*;
import java.io.*;
import java.util.Locale;

/** Publishes only completed files to shared Downloads. Pending rows survive recoverable failures. */
final class MediaPublisher implements Engine.Publisher {
    private final ContentResolver resolver;
    MediaPublisher(Context context){resolver=context.getContentResolver();}
    private static final String PENDING=MediaStore.MediaColumns.IS_PENDING;
    @Override public String publish(Job j,Engine.Control control)throws IOException{
        Uri uri=null;
        if(!j.output.isEmpty()){
            Uri prior=Uri.parse(j.output);
            try(Cursor cur=resolver.query(prior,new String[]{PENDING,MediaStore.MediaColumns.SIZE},null,null,null)){
                if(cur!=null&&cur.moveToFirst()){
                    if(cur.getInt(0)==0){if(cur.getLong(1)==j.total)return prior.toString();throw new IOException("Previously published file differs; inspect Downloads");}
                    uri=prior;
                }
            }catch(SecurityException e){throw new IOException("Cannot access pending file",e);}
        }
        if(uri==null){
            ContentValues v=new ContentValues();v.put(MediaStore.MediaColumns.DISPLAY_NAME,j.name);
            String ext=MimeTypeMap.getFileExtensionFromUrl(j.name);String mime=MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase(Locale.ROOT));
            v.put(MediaStore.MediaColumns.MIME_TYPE,mime==null?"application/octet-stream":mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/TurboFetch");v.put(PENDING,1);
            uri=resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new IOException("Cannot create public download");
            j.output=uri.toString();try{j.save();}catch(IOException e){resolver.delete(uri,null,null);j.output="";throw e;}
        }
        // 'rwt' explicitly truncates a previously interrupted pending publication, not the saved parts.
        ParcelFileDescriptor pfd=resolver.openFileDescriptor(uri,"rwt");if(pfd==null)throw new IOException("Cannot open output file");
        try(FileOutputStream out=new ParcelFileDescriptor.AutoCloseOutputStream(pfd)){Engine.copyParts(j,out,control);out.flush();out.getFD().sync();}
        control.check();ContentValues done=new ContentValues();done.put(PENDING,0);
        if(resolver.update(uri,done,null,null)!=1)throw new IOException("Cannot finalize public download");
        return uri.toString();
    }
    static void discardPending(Context context,Job j)throws IOException{
        if(j.output.isEmpty())return;Uri uri=Uri.parse(j.output);ContentResolver r=context.getContentResolver();
        try(Cursor c=r.query(uri,new String[]{PENDING},null,null,null)){
            if(c!=null&&c.moveToFirst()){
                if(c.getInt(0)!=1)throw new IOException("A published file already exists; it will not be deleted automatically");
                if(r.delete(uri,null,null)!=1)throw new IOException("Cannot remove pending output");
            }
        }catch(SecurityException e){throw new IOException("Cannot remove pending output",e);}
        j.output="";j.save();
    }
}
