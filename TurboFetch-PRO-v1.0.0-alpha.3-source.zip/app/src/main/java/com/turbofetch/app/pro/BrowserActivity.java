package com.turbofetch.app.pro;
import android.app.Activity;
import android.content.Intent;
import android.os.*;
import android.webkit.*;
import android.widget.*;
import com.turbofetch.core.Store;

/** Basic link-capture browser. Authenticated/cookie-bound and blob media are not supported. */
public final class BrowserActivity extends Activity {
    private WebView web;private EditText address;
    @Override protected void onCreate(Bundle b){super.onCreate(b);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);if(Build.VERSION.SDK_INT>=30)MainActivity.insets(root,0);setContentView(root);LinearLayout bar=new LinearLayout(this);address=new EditText(this);address.setSingleLine();address.setHint("https://example.com");bar.addView(address,new LinearLayout.LayoutParams(0,-2,1));Button go=new Button(this);go.setText("Go");bar.addView(go);root.addView(bar);web=new WebView(this);root.addView(web,new LinearLayout.LayoutParams(-1,0,1));web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
        web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){String s=r.getUrl().getScheme();return !"https".equals(s)&&!"http".equals(s);}@Override public void onPageFinished(WebView v,String u){address.setText(u);}});
        web.setDownloadListener((url,ua,disposition,mime,length)->{try{Store.validate(url);String name=android.webkit.URLUtil.guessFileName(url,disposition,mime);startActivity(new Intent(this,MainActivity.class).putExtra("url",url).putExtra("name",name).putExtra("agent",ua));}catch(Exception e){Toast.makeText(this,"Only direct HTTP(S) links are supported",Toast.LENGTH_LONG).show();}});
        go.setOnClickListener(v->{String u=address.getText().toString().trim();if(!u.contains("://"))u="https://"+u;try{Store.validate(u);web.loadUrl(u);}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}});}
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
