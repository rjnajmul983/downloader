package com.turbofetch.app.pro;
import android.app.Application;
import android.content.SharedPreferences;
import com.turbofetch.core.*;
import java.io.*;
import java.util.concurrent.*;

public final class TurboApp extends Application {
    Store store;
    String initError;
    final ConcurrentHashMap<String,Engine.Control> running=new ConcurrentHashMap<>();
    String migrationNotice="";
    final ExecutorService maintenance=Executors.newSingleThreadExecutor();
    final ExecutorService workers=Executors.newFixedThreadPool(3);
    @Override public void onCreate(){super.onCreate();if(!prefs().getBoolean("smartAutoMigrated",false)){boolean old=prefs().contains("connections");prefs().edit().putInt("connections",32).putBoolean("smartAutoMigrated",true).apply();if(old)migrationNotice="Smart Auto is now the default. Your downloads and network preferences are preserved.";}try{store=new Store(new File(getFilesDir(),"jobs"));int days=prefs().getInt("historyDays",0);if(days>0)maintenance.execute(()->{try{store.clearCompletedBefore(System.currentTimeMillis()-days*86400000L);}catch(IOException e){android.util.Log.w("TurboFetch","History retention cleanup incomplete");}});}catch(IOException e){initError=e.getMessage();}}
    SharedPreferences prefs(){return getSharedPreferences("settings",MODE_PRIVATE);}
    int connections(){return prefs().getInt("connections",32);}
    int parallel(){return Math.max(1,Math.min(3,prefs().getInt("parallel",1)));}
}
