package com.turbofetch.app.pro;
import java.util.Locale;
final class Format {
    static String bytes(long b){if(b<0)return "?";String[] u={"B","KiB","MiB","GiB","TiB"};double n=b;int i=0;while(n>=1024&&i<u.length-1){n/=1024;i++;}return String.format(Locale.US,i==0?"%.0f %s":"%.2f %s",n,u[i]);}
    static String eta(long remain,long speed){if(remain<0||speed<=0)return "—";long sec=remain/speed;return sec>=3600?sec/3600+"h "+sec%3600/60+"m":sec/60+"m "+sec%60+"s";}
}
