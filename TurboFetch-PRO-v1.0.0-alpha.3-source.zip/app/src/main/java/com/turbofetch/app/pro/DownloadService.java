package com.turbofetch.app.pro;
import android.app.*;
import android.content.*;
import android.os.*;
import android.content.pm.ServiceInfo;
import android.net.*;
import com.turbofetch.core.*;
import java.io.*;
import java.util.*;

public final class DownloadService extends Service {
    static final String CHANNEL="transfers", ACTION_PAUSE="pause_all", ACTION_START="start";
    private static final int NOTIFICATION=220;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private TurboApp app;private Network lastNetwork;private boolean stopping=false;private long waitingSince=0;
    private final Runnable tick=new Runnable(){public void run(){if(!stopping){dispatch();if(!stopping)handler.postDelayed(this,1000);}}};
    static void start(Context c){Intent i=new Intent(c,DownloadService.class).setAction(ACTION_START);c.startForegroundService(i);}
    @Override public void onCreate(){super.onCreate();app=(TurboApp)getApplication();NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Downloads",NotificationManager.IMPORTANCE_LOW));}
    @Override public int onStartCommand(Intent i,int flags,int startId){
        stopping=false;waitingSince=0;startForeground(NOTIFICATION,notification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        if(i!=null&&ACTION_PAUSE.equals(i.getAction()))pauseAll();handler.removeCallbacks(tick);handler.post(tick);return START_NOT_STICKY;
    }
    private boolean networkAllowed(){
        ConnectivityManager cm=getSystemService(ConnectivityManager.class);Network n=cm.getActiveNetwork();NetworkCapabilities cap=n==null?null:cm.getNetworkCapabilities(n);
        return cap!=null&&cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)&&(!app.prefs().getBoolean("unmetered",false)||cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED));
    }
    private void dispatch(){
        if(app.store==null){finishService();return;}
        boolean allowed=networkAllowed();
        ConnectivityManager cm=getSystemService(ConnectivityManager.class);
        Network current=cm.getActiveNetwork();NetworkCapabilities cap=current==null?null:cm.getNetworkCapabilities(current);
        boolean changed=lastNetwork!=null&&!Objects.equals(lastNetwork,current);lastNetwork=current;
        String transport=cap==null?"unknown":cap.hasTransport(NetworkCapabilities.TRANSPORT_VPN)?"vpn":cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)?"wifi":cap.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)?"cellular":"other";
        int global=32;PowerManager pm=getSystemService(PowerManager.class);int thermal=pm.getCurrentThermalStatus();
        if(thermal>=PowerManager.THERMAL_STATUS_SEVERE)global=4;else if(thermal>=PowerManager.THERMAL_STATUS_MODERATE)global=8;
        if(pm.isPowerSaveMode())global=Math.min(global,8);
        int budget=Math.max(1,global/app.parallel());
        for(Job j:app.store.all()){
            Engine.Control c=app.running.get(j.id);
            if(c!=null){c.workerBudget=budget;if((!allowed||changed)&&j.state==Job.State.RUNNING){j.state=Job.State.PAUSING;c.pause();}}
            else if(allowed&&j.state==Job.State.WAITING_NETWORK&&j.recoverAutomatically){j.state=Job.State.QUEUED;j.error="";try{j.save();}catch(IOException e){j.error=e.getMessage();}}
        }
        if(allowed)waitingSince=0;else if(waitingSince==0)waitingSince=SystemClock.elapsedRealtime();
        if(allowed){
            List<Job> jobs=app.store.all();Collections.reverse(jobs);
            for(Job j:jobs){
                if(app.running.size()>=app.parallel())break;if(j.state!=Job.State.QUEUED)continue;
                Engine.Control control=new Engine.Control();control.workerBudget=budget;control.network=transport;control.dynamicRanges=true;control.directStorage=true;if(app.running.putIfAbsent(j.id,control)!=null)continue;
                j.connections=app.connections();j.recoverAutomatically=true;j.state=Job.State.RUNNING;j.inFlight=true;
                try{j.save();}catch(IOException e){j.state=Job.State.FAILED;j.error=e.getMessage();j.inFlight=false;app.running.remove(j.id,control);continue;}
                app.workers.execute(()->{try{new Engine().run(j,control,new MediaPublisher(this));}finally{app.running.remove(j.id,control);}});
            }
        }
        boolean queued=false;for(Job j:app.store.all())if(j.state==Job.State.QUEUED||j.state==Job.State.WAITING_NETWORK){queued=true;break;}
        if(app.running.isEmpty()&&(!queued||(!allowed&&SystemClock.elapsedRealtime()-waitingSince>120_000))){finishService();return;}
        if(Build.VERSION.SDK_INT<33||checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED)getSystemService(NotificationManager.class).notify(NOTIFICATION,notification());
    }
    private Notification notification(){
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent pause=PendingIntent.getService(this,1,new Intent(this,DownloadService.class).setAction(ACTION_PAUSE),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        long speed=0;int running=0;String detail="Preparing queue";if(app!=null&&app.store!=null){for(Job j:app.store.all())if(j.active()){speed+=j.speed;running++;detail=j.name;}}
        return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("TurboFetch • "+Format.bytes(speed)+"/s")
            .setContentText(running==0?(waitingSince>0?"Waiting for network • open app to resume queue":"Preparing downloads"):running+" active • "+detail).setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
            .addAction(new Notification.Action.Builder(null,"Pause all",pause).build()).build();
    }
    static void pause(TurboApp app,Job j){
        j.recoverAutomatically=false;try{j.save();}catch(IOException e){j.error=e.getMessage();}Engine.Control control=app.running.get(j.id);
        if(control!=null){if(j.state==Job.State.RUNNING||j.state==Job.State.PAUSING||j.state==Job.State.FINALIZING){j.state=Job.State.PAUSING;control.pause();}else if(j.state==Job.State.WAITING_NETWORK){j.state=Job.State.PAUSED;try{j.save();}catch(IOException e){j.error=e.getMessage();}}}
        else if(j.state==Job.State.QUEUED||j.state==Job.State.WAITING_NETWORK){j.state=Job.State.PAUSED;try{j.save();}catch(IOException e){j.error=e.getMessage();}}
    }
    private void pauseAll(){if(app.store!=null)for(Job j:app.store.all())pause(app,j);}
    private void finishService(){stopping=true;handler.removeCallbacks(tick);stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
    @android.annotation.TargetApi(35) @Override public void onTimeout(int startId,int fgsType){for(Engine.Control c:app.running.values())c.pause();finishService();}
    @Override public void onDestroy(){handler.removeCallbacks(tick);for(Engine.Control c:app.running.values())c.pause();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
