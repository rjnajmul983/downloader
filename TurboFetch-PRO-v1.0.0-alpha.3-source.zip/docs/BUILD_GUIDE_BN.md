# ফোন দিয়ে alpha.3 APK তৈরি

১. আগের repository ব্যবহার করতে পারেন, অথবা Private repository তৈরি করুন। নতুন `TurboFetch-PRO-v1.0.0-alpha.3-source.zip` root-এ আপলোড করুন। নাম বদলাবেন না। ZIP extract করবেন না।
২. `.github/workflows/android-build.yml` ফাইলটি নতুন আলাদা YAML-এর সম্পূর্ণ কোড দিয়ে প্রতিস্থাপন করুন। Commit করুন।
৩. Actions → TurboFetch PRO - Build APK → Run workflow। push করলেও রান হয়।
৪. সফল হলে Artifacts → TurboFetch-PRO-v1.0.0-alpha.3-APK থেকে ZIP ডাউনলোড করে app-debug.apk বের করে ইনস্টল করুন।
৫. Smart Auto ডিফল্ট। লিংক দিয়ে Download চাপুন, অন্য performance settings প্রয়োজন নেই।

SDK/Gradle স্থানীয়ভাবে পাওয়া যায়নি; GitHub-এ প্রথম Android build ও device test প্রয়োজন। Build ব্যর্থ হলে সংশ্লিষ্ট step-এর log দেখুন। Optional large_test চালালে দুটি ৫ GiB host test হবে, ১১ GiB-এর বেশি খালি disk দরকার।

## Signing / update
Package ID alpha.1-এর মতো com.turbofetch.app.pro। কিন্তু আলাদা GitHub runner-এর debug signing key ভিন্ন হতে পারে। একই certificate না হলে Android সরাসরি update করতে দেবে না। অসম্পূর্ণ ফাইল/হিস্টোরি থাকলে আনইনস্টল করবেন না। ভবিষ্যতের জন্য নিজের স্থায়ী signing keystore রাখুন। CI-তে optional secrets: TURBO_KEYSTORE_B64 (নিজের keystore-এর base64), TURBO_STORE_PASSWORD, TURBO_KEY_ALIAS, TURBO_KEY_PASSWORD। সবগুলো দিলে debug APK owner key দিয়ে sign হবে। কোনো secret সরাসরি repository-তে লিখবেন না। পুরোনো certificate না থাকলে নতুন key আগের APK update করতে পারবে না।

## ডিভাইস টেস্ট
একটি একই range-supported ফাইল দিয়ে ১–৫ GiB download, pause, reopen, resume করুন। Wi-Fi থেকে mobile data switch পরীক্ষা করুন। History clear করার সময় completed ফাইল যেন থাকে এবং paused job যেন সুরক্ষিত থাকে। Real mobile speed comparison একই server/file/network দিয়ে করুন।
