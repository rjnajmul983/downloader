# alpha.3 host test results
- Baseline alpha.2 rerun: 12 core + 8 Smart Auto tests passed.
- Upgraded core: all 20 retained tests and 8 new HyperSpeed tests passed (28 total), see core-test-results.txt.
- 5 GiB new direct/dynamic mode: paused after 2,161,046,155 durable bytes, reopened, resumed with cap 32 (from 8), no committed range requested again except capability probe; SHA-256 exact. See large-direct-test-results.txt. This run preceded the subsequent shared-origin cooldown and extra metadata-bound check, which were covered by the final small-file regression suite.
- 5 GiB legacy segmented mode: paused after 2,190,474,999 bytes, reopened/resumed, exact SHA-256 and no committed ranges re-requested. See large-test-results.txt.
- Hash: 5fe9efe001aab0eb708687a5ffe68a9702f8200ecb2fd546732b950379347206 for both generated 5 GiB outputs.
- Tests execute actual HTTP requests on localhost, not mocks of the engine; process reopen is store reopening, not an Android process kill or reboot. Optional tests in workflow.
- Android compilation, lint, instrumentation, signature update, storage provider and device runtime tests not executed locally (SDK/Gradle unavailable; DNS failure). No APK generated. Full 55-item master test list not completed.
