# Original APK recovery and bug evidence

Input: `TurboFetch-Download-Manager-v0.4.0.apk`, SHA-256 `00fa15ad6fb3b64bc89f1bcb69c7757ba3e64004e7bed742cbe803b6f6ca14fa`.

The ZIP integrity check passed. The archive contains 8 DEX files, AndroidManifest.xml, resources, and `libjlibtorrent.so` for arm64-v8a, armeabi-v7a, x86 and x86_64. Original APK build metadata identifies Android Gradle Plugin 8.9.2. DEX class descriptors contain `com.turbofetch.app` classes; the new application is deliberately assigned `com.turbofetch.app.pro`.

## Verified history defect

`classes3.dex`, `JobStore.clearFinishedHistory()` calls `List.removeIf` with a predicate and then `save()`. Its synthetic lambda `lambda$clearFinishedHistory$0` compares `DownloadJob.status` with only the two literal strings `COMPLETED` and `CANCELLED`. Failed and paused records are not matched. The raw code-unit reference inspection is saved in `original-history-bytecode.txt` and can be reproduced with `python tools/history_refs.py <original.apk>`. If even completed records remain, that additional defect was not reproduced here.

The new Store uses independent job records and deletes the manifest before cleaning temporary data. UI distinguishes history-only deletion, explicit partial deletion, and file-and-history deletion. Tests cover persistent completed/failed cleanup and preservation of partial records.

## Pause/resume defect

The user's observed old behavior (resume from zero) is the input bug report. The old TurboEngine contains `prepareParts`, `ranged`, `downloadPart`, `stream`, `validate`, and strings `Range`, `Content-Range`, `If-Range`, `ETag`, `Last-Modified`. This proves range-related code existed, not that its persistence was correct. The exact original failing branch has not been proven: the old APK could not be run here and full Java decompilation was blocked. The new engine was rewritten around validated ranges and durable per-part checkpoints rather than claiming to patch a specific old branch.

## Recovery boundary

The recovered data consists of APK class/method inventory, selected raw DEX instructions, resource/archive metadata, and original AGP version. See `original-apk-inventory.txt`. `tools/inspect_apk.py` and `tools/history_refs.py` are small read-only DEX inspection utilities, not general decompilers. No source from the old APK has been misrepresented as recovered Java source. The new `app/` and `core/` modules are newly authored.

If JADX is available, run `bash tools/recover-original.sh /path/to/TurboFetch-Download-Manager-v0.4.0.apk` for a separate decompiled tree. Decompiled Java and resources need manual review; Gradle files and signing keys are not guaranteed recoverable. Do not merge recovered code unreviewed.

The build environment had Java 21 with `javac --release 17`, no Gradle, Android SDK, JADX or APK signing/build tools. Direct downloads from GitHub, Gradle and Google SDK hosts failed due to DNS/network restrictions. The GitHub Actions workflow is the intended next build environment.
