# Alpha.2 local test evidence

Actual alpha.1 project baseline: 12/12 original core tests passed. Final alpha.2: all 12 original core integration tests + 8 new Smart Auto integration/controller tests passed (20 total). Raw logs included. New tests cover deterministic controller selection above 8, lower worker selection on flat throughput, cap and buffers, short downloads, profiles and expiry, simulated alpha.1 metadata compatibility and resume with increased cap, recovery intent, and safe completed history retention.

## Actual localhost adaptive worker benchmark
`bash tools/test-extra.sh smart`: identical 128 MiB deterministic payload, simulated per-stream rate limit, one run per cap, full output SHA-256 checked. New engine cap 8: peak 8 workers, 21.21s, 6.04 MiB/s. New engine cap 32: peak 12 workers, 16.79s, 7.63 MiB/s. Both passed. ~26% higher average throughput in this specific comparison. This compares the upgraded engine under two caps, NOT original APK/alpha.1 against alpha.2, not a mobile internet benchmark, and not a guarantee. Lower cap may be better on other servers. Controller synthetic tests verify downward optimization independently.

## Final 5 GiB acceptance
`bash tools/test-extra.sh large`: PASS; 5,368,709,120 bytes, paused after 2,159,935,329 durable bytes, store reopened, no committed ranges re-requested except one-byte capability probe, final SHA-256 `5fe9efe001aab0eb708687a5ffe68a9702f8200ecb2fd546732b950379347206`, elapsed 20.2s on localhost. Large test retains existing 8-worker cap, not a mobile speed test. Host reopen is not actual Android process kill or reboot.

## Build limitations
YAML parsed and each run script checked with bash -n. Java core compiled using --release 17. Android sources inspected for syntax; SDK and Gradle not available, attempted network download failed DNS. No APK, Android build, device or CI execution verified. The optional signing configuration has not been exercised. Real thermal behavior, network handover, Android migration and background execution, speed comparisons on actual devices and legacy feature restoration remain to be tested. Raw alpha.1 results retained under docs/alpha1-baseline.
