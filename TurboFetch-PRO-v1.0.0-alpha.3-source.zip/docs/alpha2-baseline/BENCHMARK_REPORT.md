# Controlled benchmark

See TEST_REPORT.md and benchmark-results.txt. Same deterministic 128 MiB resource: cap 8, 6.04 MiB/s; cap 32, 7.63 MiB/s, peak 12 workers, SHA-256 correct for both. One run per cap, no statistical confidence interval. Synthetic rate-limited localhost server. It is not alpha.1 vs alpha.2, not a real ISP comparison. Additional same-device A/B tests required.
