# Local testing evidence

Environment: OpenJDK 21 compiler with Java 17 release target. Local HTTP server via JDK HttpServer. Actual payloads, disk checkpoints, range requests, and output SHA-256 were exercised. See the verbatim result files.

## HTTP integration

`bash tools/test-core.sh`: **12 passed**. Includes simulated process reopen/uncommitted file tail; multi-segment pause/resume with zero previously committed ranges requested again; completed history deletion without deleting file; ETag change; server returns HTTP 200 instead of 206; invalid Content-Range; no-range server; explicit restart; unknown-length stream; SHA-256 mismatch; failed history cleanup; zero-byte resource. This is a host simulation of reopen, not an Android force-stop or reboot test.

## Large-file acceptance

`bash tools/test-extra.sh large`: **PASS**, generated 5 GiB (5,368,709,120 bytes), paused after 2,167,341,056 durable bytes, reopened the job store, resumed without re-requesting any previously committed range (excluding the 1-byte capability probe), verified output length and independently computed SHA-256. Elapsed 25.0 seconds for transfer/pause/reopen/finalization/output verification on localhost; not a mobile speed result. Actual output SHA-256: `5fe9efe001aab0eb708687a5ffe68a9702f8200ecb2fd546732b950379347206`.

## Controlled benchmark

`bash tools/test-extra.sh benchmark`: three runs per mode, same 24 MiB deterministic server payload with a simulated per-stream throughput ceiling; each output verified. 1 connection cap: median 3.277 seconds / 7.32 MiB/s. Adaptive 8 cap: median 0.886 seconds / 27.09 MiB/s. Ratio 3.70x on this test only, including final publication. Not old vs new, not a real internet/ISP or device benchmark. The exact original APK could not be run. A server without independent range throughput limits may show little or no acceleration.

## Not tested yet

Android SDK compilation, APK installation, device-side MediaStore and foreground notifications, actual OS process kill/reboot/Doze, vendor battery restrictions, Android 16, thermal behavior, real-world download speed, release signing, and 10/50 GiB files. A successful Java test does not imply a verified Android APK. Before a production release, run the GitHub build, inspect lint, install on a test phone, compare identical public downloadable files against the old app, and verify all remaining device behavior.
