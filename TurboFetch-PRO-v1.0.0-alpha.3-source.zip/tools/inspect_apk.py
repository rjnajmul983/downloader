import zipfile,struct,sys
p=sys.argv[1]
def scan(b):
 u=lambda o:struct.unpack_from('<I',b,o)[0]
 h=lambda o:struct.unpack_from('<H',b,o)[0]
 def leb(o):
  v=0;s=0
  while True:
   c=b[o];o+=1;v|=(c&127)<<s;s+=7
   if c<128:return v,o
 def st(i):
  o=u(u(60)+i*4);_,o=leb(o);e=b.index(0,o);return b[o:e].decode('utf8','replace')
 strings=[st(i) for i in range(u(56))]; types=[strings[u(u(68)+4*i)] for i in range(u(64))]
 mo=u(92); methods=[(types[h(mo+8*i)],strings[u(mo+8*i+4)]) for i in range(u(88))]
 for i in range(u(96)):
  o=u(100)+32*i; name=types[u(o)]; data=u(o+24)
  if not name.startswith('Lcom/turbofetch/') or not data:continue
  a=[]
  for _ in range(4):v,data=leb(data);a.append(v)
  for _ in range(a[0]+a[1]):_,data=leb(data);_,data=leb(data)
  out=[]
  for n in a[2:]:
   idx=0
   for _ in range(n):
    d,data=leb(data);idx+=d;_,data=leb(data);code,data=leb(data);out.append((methods[idx][1],code))
  print(name,', '.join(x[0] for x in out if not x[0].startswith('lambda$')))
  if 'JobStore;' in name:
   for m,c in out:
    if m=='clearFinishedHistory' and c:
     print('clearFinishedHistory code units:',b[c+16:c+16+u(c+12)*2].hex())
  if 'TurboEngine;' in name:
   print('Relevant strings:',[s for s in strings if s in ('Range','If-Range','ETag','Last-Modified','Content-Range') or 'resume' in s.lower() and len(s)<120][:100])
with zipfile.ZipFile(p) as z:
 print(z.read('META-INF/com/android/build/gradle/app-metadata.properties').decode())
 for n in z.namelist():
  if n.endswith('.dex'): print(n);scan(z.read(n))
