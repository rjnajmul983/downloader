#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then echo 'Usage: bash tools/recover-original.sh original.apk' >&2; exit 2; fi
command -v jadx >/dev/null || { echo 'Install JADX from its official release: https://github.com/skylot/jadx/releases' >&2; exit 1; }
jadx --show-bad-code -d recovered-original "$1"
