# Changelog
## 1.0.0-alpha.3
- Persistent explicit range overrides and cooperative live tail splitting.
- Single private positional-write payload with per-range checkpoints; legacy backend fallback.
- Shared per-origin Retry-After cooldown; best-effort connection cancellation during pause.
- Small-file start optimization, real backend/range status in UI, alpha.3 build workflow and APK checksum.
- Expanded host regression and large-file tests. Android build not executed locally.
- Public MediaStore publication still copies; HTTP/3, dual-network and other premium modules deferred.

## 1.0.0-alpha.2
Smart Auto 32-worker default, adaptive buffers, learned profiles, persistent recovery intent, thermal limits and history cleanup. Prior reports in docs/alpha2-baseline.
